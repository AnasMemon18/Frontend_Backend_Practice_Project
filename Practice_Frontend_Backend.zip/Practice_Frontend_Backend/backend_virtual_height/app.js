const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const cors = require("cors");
const routes = require('./routes/user_routes');
const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(routes);

const url = "mongodb+srv://root:root@cluster0.jzewljl.mongodb.net/virtual_height?retryWrites=true&w=majority";

mongoose.connect(url , {useNewUrlParser: true},
    app.listen(5000, ()=>console.log("Server started on port 5000."))
)





