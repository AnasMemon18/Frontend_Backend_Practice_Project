const express = require("express");

const userController = require("../controller/user_controller");

const router = express.Router();

router.get('/', userController.getUsers);
router.post('/register', userController.userRegister);
router.post('/updateUser', userController.updateUser);
router.post('/deleteUser', userController.deleteUser);
router.post('/updateHoja', userController.updateHoja);
router.post('/userLogin', userController.userLogin);

module.exports = router;