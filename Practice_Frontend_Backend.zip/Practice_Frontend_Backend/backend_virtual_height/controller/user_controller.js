const User = require('../models/user');

const getUsers = (req, res, next) => {
    User.find().then(result => {
        res.json({data: result});
    })
}

const userRegister = (req, res, next) => {
    const {email, password, phoneNumber, address} = req.body;

    User.findOne({email:email}).then(result => {
        if(result==null){
            const user = new User({
                email,
                password,
                phoneNumber,
                address
            })

            user.save().then(user => {
                res.status(201).json({msg: "User registered successfully!", status: 201});
            })
        }
        else{
            res.status(200).json({msg: "User already registered!", status: 200});
        }
    }).catch(err => {
        console.log("Error from db: ", err);
    })
}

const updateUser = (req, res, next) => {
    console.log("Updateuser:  ", req.body);
    
    User.findOne({_id:req.body.id}).then(result=>{
        res.json({data:result, msg:"User found sucessfully!"});
    }).catch(err =>{
        console.log("Error: ", err);
    })
}

const updateHoja = (req, res, next) => {
    User.findOneAndUpdate(
        { _id: req.body._id }, 
        {
          $set: {
            email: req.body.email,
            password: req.body.password,
            phoneNumber: req.body.phoneNumber,
            address: req.body.address,
          },
        },
        { new: true }
      )
        .then((updatedUser) => {
          if (updatedUser === null) {
            
          } else {
           
            res.status(201).json({ message: 'User updated successfully', user: updatedUser, status:201 });
          }
        })
        .catch((err) => {
          console.log("Error: ", err);
          res.status(500).json({ error: 'Internal server error' });
        });
}

const deleteUser = (req, res, next) => {
    User.deleteOne({_id:req.body.id}).then(result=>{
        res.json({data:result, msg:"User deleted!!!"});
    }).catch(err =>{
        console.log("Error: ", err);
    })
}

const userLogin = (req, res, next) => {
    const {email, password} = req.body;

    User.find({email:email}).then(result => {
        if(result == null){

        }
        else{
            console.log(result);
        }
    })
};

module.exports= {
    getUsers, userRegister, updateUser, deleteUser, updateHoja, userLogin
}