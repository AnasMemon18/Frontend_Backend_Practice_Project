import React, {useState, useEffect} from 'react'
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const navigate = useNavigate();
  const [data, setData] = useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    setData((prevData) => ({
      ...prevData,
      [e.target.name]: e.target.value,
    }));
  };

  useEffect(() => {
  }, [data]);


  const handleSubmit = (e) => {
    e.preventDefault();
    fetch("http://localhost:5000/userLogin", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    }).then((response) => response.json())
    .then(data => {
      console.log(data);
      if(data.status === 200){
        console.log(data.msg)
        navigate('/');
      }
    }).catch(err => {
      console.log("Error: ", err);
    })
  }

  return (
    <div>
      
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="email"
          placeholder="Email: "
          onChange={handleChange}
        />
        <input
          type="password"
          name="password"
          placeholder="Password: "
          onChange={handleChange}
        />
        <input
          type="text"
          name="phoneNumber"
          placeholder="Phone Number: "
          onChange={handleChange}
        />
        <input
          type="text"
          name="address"
          placeholder="Address: "
          onChange={handleChange}
        />
        <button type="submit">Register</button>
      </form>

    </div>
  )
}

export default Login