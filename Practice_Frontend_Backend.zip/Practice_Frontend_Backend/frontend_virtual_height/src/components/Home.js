import  React, {useState, useEffect} from "react";
import { useNavigate } from "react-router-dom";
const Home = () => {
  const [users, setUsers] = React.useState([]);
  const [showForm, setShowForm] = useState(false);
  const [data, setData] = useState({
    _id: "",
    email: "",
    password: "",
    phoneNumber: "",
    address: "",
  });

  React.useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await fetch("http://localhost:5000");
      const data = await response.json();
      const arryLike = Array.from(data.data);
      console.log("Data type:", Array.isArray(arryLike));
      setUsers(Array.from(data.data));
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const updateHandler = (id) => {
    const data = { id: id };
    fetch("http://localhost:5000/updateUser", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })
      .then((response) => response.json())
      .then((data) => {
        setShowForm(true);
        setData(data.data)
      })
      .catch();
  };

  const deleteHandler = (id) => {
    const data = { id: id };
    fetch("http://localhost:5000/deleteUser", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data.msg);
        fetchData();
      })
      .catch((err) => {
        console.log(err);
      });
  };


  const handleChange = (e) => {
    setData((prevData) => ({
      ...prevData,
      [e.target.name]: e.target.value,
    }));
  };

  useEffect(() => {
    console.log("Dataaaa: ", data)
  }, [data]);


  const handleSubmit = (e) => {
    e.preventDefault();
    fetch("http://localhost:5000/updateHoja", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    }).then((response) => response.json())
    .then(data => {
      if(data.status === 201){  
        setShowForm(false);
        fetchData();
      }
    }).catch(err => {
      console.log("Error: ", err);
    })
  }

  return (
    <div>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Address</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((item, index) => (
            <tr key={item._id}>
              <td>{item._id}</td>
              <td>{item.email}</td>
              <td>{item.phoneNumber}</td>
              <td>{item.address}</td>
              <td>
                <button onClick={() => updateHandler(item._id)}>Update</button>
                <button onClick={() => deleteHandler(item._id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

     { showForm && <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="email"
          value={data.email}
          placeholder="Email: "
          onChange={handleChange}
        />
        <input
          type="password"
          name="password"
          value={data.password}
          placeholder="Password: "
          onChange={handleChange}
        />
        <input
          type="text"
          name="phoneNumber"
          value={data.phoneNumber}
          placeholder="Phone Number: "
          onChange={handleChange}
        />
        <input
          type="text"
          name="address"
          value={data.address}
          placeholder="Address: "
          onChange={handleChange}
        />
        <button type="submit">Update</button>
      </form> }
    </div>
  );
};

export default Home;
